import csv
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import sqlite3
from alpha_vantage.timeseries import TimeSeries
import pandas as pd

def main_application():
    root = tk.Tk()
    root.title("Prehľad databáze")
    root.geometry("1200x800")  # Zvýšenie veľkosti hlavného okna

    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Treeview", background="#D3D3D3",
                    foreground="black", rowheight=25, fieldbackground="#D3D3D3")
    style.map('Treeview', background=[('selected', '#347083')])

    def fetch_table_names(db_file='projekt.db'):
        try:
            conn = sqlite3.connect(db_file)
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = cursor.fetchall()
            return [table[0] for table in tables]
        except sqlite3.Error as e:
            print(f"Vyskytla sa chyba: {e}")
            return []
        finally:
            conn.close()

    def fetch_table_data(db_file, table_name):
        try:
            conn = sqlite3.connect(db_file)
            cursor = conn.cursor()
            if table_name == 'PrehladAkcii':
                query = '''
                SELECT cp.Nazov, cp.Ticker_Symbol, t.Open_Time, t.Open_Price
                FROM CennyPapier cp
                JOIN Transakcia t ON cp.ID_Cenneho_Papiera = t.ID_Cenneho_Papiera
                ORDER BY cp.Ticker_Symbol, t.Open_Time
                '''
                cursor.execute(query)
            else:
                cursor.execute(f"SELECT * FROM {table_name}")
            columns = [description[0] for description in cursor.description]
            data = cursor.fetchall()
            return columns, data
        except sqlite3.Error as e:
            print(f"Chyba pri získavaní dát: {e}")
            return [], []
        finally:
            conn.close()

    def get_stock_info(symbol):
        API_KEY = 'X6XCYJIFFLQCF07I'
        ts = TimeSeries(key=API_KEY, output_format='pandas')
        try:
            data, meta_data = ts.get_quote_endpoint(symbol=symbol)
            price = data['05. price'].iloc[0]
            return price
        except Exception as e:
            print(f"Chyba pri získavaní informácií o akcii {symbol}: {e}")
            return 0.0

    def show_table_data(table_name):
        for widget in main_frame.winfo_children():
            widget.destroy()

        columns, data = fetch_table_data('projekt.db', table_name)

        if table_name == 'PrehladAkcii':
            columns += ('Aktuálna cena',)
            new_data = []
            total_open_price = 0.0
            total_current_value = 0.0
            performance_list = []
            for row in data:
                ticker_symbol = row[1]
                current_price = float(get_stock_info(ticker_symbol))
                total_open_price += row[3] if row[3] else 0.0
                total_current_value += current_price
                performance = (current_price / row[3]) if row[3] else 0
                performance_list.append((row[0], ticker_symbol, performance))
                new_row = row + (current_price,)
                new_data.append(new_row)
            data = new_data

            # Sort performance list
            performance_list.sort(key=lambda x: x[2], reverse=True)
            top5_best = performance_list[:5]
            top5_worst = performance_list[-5:]

            # Display metrics
            metrics_frame = ttk.Frame(main_frame, height=100)
            metrics_frame.pack(fill='x')

            ttk.Label(metrics_frame, text=f"Total Open Price: {round(total_open_price, 2)}", font=('Arial', 12)).pack(side='left', padx=10, pady=5)
            ttk.Label(metrics_frame, text=f"Total Current Value: {round(total_current_value, 2)}", font=('Arial', 12)).pack(side='left', padx=10, pady=5)

            # Display top 5 best performance
            best_frame = ttk.Frame(metrics_frame)
            best_frame.pack(side='left', padx=10, pady=5)
            ttk.Label(best_frame, text="TOP 5 Best Performance Stocks:", font=('Arial', 12, 'bold')).pack(anchor='w')
            for name, ticker, performance in top5_best:
                ttk.Label(best_frame, text=f"{name} ({ticker}): {performance:.2f}", font=('Arial', 10)).pack(anchor='w')

            # Display top 5 worst performance
            worst_frame = ttk.Frame(metrics_frame)
            worst_frame.pack(side='left', padx=10, pady=5)
            ttk.Label(worst_frame, text="TOP 5 Worst Performance Stocks:", font=('Arial', 12, 'bold')).pack(anchor='w')
            for name, ticker, performance in top5_worst:
                ttk.Label(worst_frame, text=f"{name} ({ticker}): {performance:.2f}", font=('Arial', 10)).pack(anchor='w')

        # Frame for Treeview and Scrollbars
        data_frame = ttk.Frame(main_frame)
        data_frame.pack(expand=True, fill='both')

        # Scrollbars
        tree_scroll_y = ttk.Scrollbar(data_frame, orient="vertical")
        tree_scroll_y.pack(side='right', fill='y')
        tree_scroll_x = ttk.Scrollbar(data_frame, orient="horizontal")
        tree_scroll_x.pack(side='bottom', fill='x')

        tree = ttk.Treeview(data_frame, columns=columns, show="headings", yscrollcommand=tree_scroll_y.set, xscrollcommand=tree_scroll_x.set)
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, anchor="center")
        for row in data:
            tree.insert("", tk.END, values=row)

        tree.pack(expand=True, fill='both')

        # Configure scrollbars
        tree_scroll_y.config(command=tree.yview)
        tree_scroll_x.config(command=tree.xview)

    # Sidebar for table selection
    sidebar = ttk.Frame(root, width=100)  # Zmenšenie sidebaru na 100 pixelov
    sidebar.pack(side='left', fill='y')

    table_tree = ttk.Treeview(sidebar)
    table_tree.pack(expand=True, fill='both')

    table_tree["columns"] = ("one")
    table_tree.column("#0", width=100, minwidth=100)
    table_tree.heading("#0", text="Názov tabuľky", anchor=tk.W)

    tables = fetch_table_names()
    tables.append('PrehladAkcii')  # Add the new table for overview
    for table in tables:
        table_tree.insert("", tk.END, text=table)

    def on_tree_select(event):
        selected_table = table_tree.item(table_tree.selection())['text']
        show_table_data(selected_table)

    table_tree.bind("<<TreeviewSelect>>", on_tree_select)

    # Main Frame for showing table data and metrics
    main_frame = ttk.Frame(root)
    main_frame.pack(expand=True, fill='both', side='right')

    root.mainloop()

def welcome_screen():
    def fetch_account_names(db_file='projekt.db'):
        try:
            conn = sqlite3.connect(db_file)
            cursor = conn.cursor()
            cursor.execute("SELECT Nazov_Uctu FROM Ucet")
            accounts = cursor.fetchall()
            return [account[0] for account in accounts]
        except sqlite3.Error as e:
            print(f"Chyba pri získavaní názvov účtov: {e}")
            return []
        finally:
            conn.close()

    welcome = tk.Tk()
    welcome.title("Vitajte")
    welcome.geometry("400x300")

    tk.Label(welcome, text="Vyberte účet:").pack(pady=(10, 0))

    accounts = fetch_account_names()
    account_var = tk.StringVar()
    account_combo = ttk.Combobox(welcome, textvariable=account_var, values=accounts, state="readonly")
    account_combo.pack(pady=10)

    def load_data(selected_account):
        if selected_account:
            print(f"Načítavam dáta pre účet: {selected_account}")
        else:
            messagebox.showerror("Chyba", "Musíte vybrať účet!")
            return

        root = tk.Tk()
        root.withdraw()

        csv_file_path = filedialog.askopenfilename(title="Vyberte CSV súbor", filetypes=[("CSV súbory", "*.csv")])

        if not csv_file_path:
            print("Nie je vybraný žiadny súbor.")
            return

        db_path = 'projekt.db'
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        with open(csv_file_path, newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)

            cenny_papier_data = set()
            for row in reader:
                ticker_symbol = row['Ticker'].strip()
                name = row['Name'].strip()
                if ticker_symbol == "" or name == "":
                    continue  # Skip rows without ticker symbol or name

                typ_transakcie = 'Market buy' if row['Action'] == 'Market buy' else 'Market sell'
                open_time = row['Time']
                price_share = row['Price / share'].strip()
                open_price = float(price_share) if price_share else 0.0
                mnozstvo = row['No. of shares'].strip()
                mnozstvo = float(mnozstvo) if mnozstvo else 0.0
                cursor.execute('''
                        INSERT OR IGNORE INTO CennyPapier (Ticker_Symbol, Nazov)
                        VALUES (?, ?)
                    ''', (ticker_symbol, name))
                cursor.execute("SELECT ID_Cenneho_Papiera FROM CennyPapier WHERE Ticker_Symbol = ?", (ticker_symbol,))
                result = cursor.fetchone()
                if result:
                    id_cenneho_papiera = result[0]
                    cursor.execute('''INSERT INTO Transakcia (ID_Cenneho_Papiera, Typ, Open_Time, Open_Price, Mnozstvo)
                                      VALUES (?, ?, ?, ?, ?)''',
                                   (id_cenneho_papiera, typ_transakcie, open_time, open_price, mnozstvo))
                else:
                    print(f"Cenný papier s tickerom {ticker_symbol} nebol nájdený.")

        conn.commit()
        conn.close()
        print("Dáta boli úspešne načítané a vložené do databázy.")

    def on_continue():
        selected_account = account_var.get()
        if selected_account:
            print(f"Vybraný účet: {selected_account}")
            welcome.destroy()
        else:
            messagebox.showerror("Chyba", "Musíte vybrať účet!")

    continue_button = ttk.Button(welcome, text="Pokračovať", command=on_continue)
    load_button = ttk.Button(welcome, text="Načítať dáta", command=lambda: load_data(account_var.get()))
    continue_button.pack(pady=10)
    load_button.pack(pady=10)

    welcome.mainloop()

if __name__ == "__main__":
    welcome_screen()
    main_application()
